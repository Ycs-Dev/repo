export RSYNC_RSH=ssh
